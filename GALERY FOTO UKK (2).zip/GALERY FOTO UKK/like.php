<?php
    include "db.php";
    session_start();

    if(!isset($_SESSION['admin_id'])){
        //Untuk bisa like harus login dulu
        header("location:detail-image.php");
    }else{
        $fotoid=$_GET['image_id'];
        $userid=$_SESSION['admin_id'];
        //Cek apakah user sudah pernah like foto ini apa belum

        $sql=mysqli_query($conn,"select * from tb_like where image_id='$image_id' and admin_id='$admin_id'");

        if(mysqli_num_rows($sql)==1){
            //User sudah pernah like foto ini
            header("location:detail-image.php");
        }else{
            $tanggal_like=date("Y-m-d");
            mysqli_query($conn,"insert into tb_like values('','$image_id','$admin_id','$tanggal_like')");
            header("location:detail-image.php");
        }
    }


?>